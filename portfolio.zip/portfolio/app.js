function home() {
  document.getElementsByClassName('hero')[0].scrollIntoView({
    behavior: 'smooth'
  });
}
function about() {
  document.getElementsByClassName('about-me')[0].scrollIntoView({
    behavior: 'smooth'
  });
}
function skill() {
  document.getElementsByClassName('tech-stack')[0].scrollIntoView({
    behavior: 'smooth'
  })
}
function education() {
  document.getElementsByClassName('education-section')[0].scrollIntoView({
    behavior: 'smooth'
  })
}

function Contact() {
  document.getElementsByClassName('contact')[0].scrollIntoView({
    behavior: 'smooth'
  })
}